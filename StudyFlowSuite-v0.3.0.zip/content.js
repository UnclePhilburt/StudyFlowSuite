// Content script - runs on every webpage to detect quiz questions
console.log('StudyFlowSuite loaded');

// Detect quiz questions on the page
function detectQuiz() {
  const quizData = {
    question: null,
    answers: [],
    found: false,
    debug: []
  };

  console.log('=== QUIZ DETECTION DEBUG ===');

  // Look for any text that might be a question (very broad search)
  const allText = document.body.innerText;
  console.log('Page text length:', allText.length);

  // Common quiz patterns to look for (includes Canvas, Blackboard, Moodle, etc.)
  const questionSelectors = [
    // Canvas LMS
    '.question_text',
    '.quiz_question',
    '[class*="question_text"]',
    // Blackboard
    '.questionText',
    '.vtbegenerated',
    // Moodle
    '.qtext',
    '.formulation',
    // Generic
    'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
    '[class*="question"]',
    '[id*="question"]',
    '[role="heading"]',
    'p strong',
    'p b',
    'div strong',
    'div b',
    '.quiz-question',
    '.question-text',
    'label',
    'p',
    'div'
  ];

  // Find the question - be very lenient
  for (const selector of questionSelectors) {
    const elements = document.querySelectorAll(selector);
    console.log(`Checking selector "${selector}": found ${elements.length} elements`);

    for (const el of elements) {
      const text = el.textContent.trim();

      // Skip if it looks like a page title (contains "Practice Test", "Certification", etc.)
      const isPageTitle = /practice\s+test|certification|exam\s+title|test\s+name/i.test(text);
      if (isPageTitle) {
        console.log(`Skipping page title: ${text.substring(0, 50)}`);
        continue;
      }

      // Very lenient - any text with a question mark or longer than 50 chars with keywords
      const hasQuestionMark = text.includes('?');
      const hasKeywords = /\b(which|what|who|when|where|why|how|select|choose|assessment|monitoring|noted|nurse|patient|client|infant|newborn|should|would|could|teaching)\b/i.test(text);
      const isLongEnough = text.length > 30 && text.length < 2000;

      if ((hasQuestionMark || (hasKeywords && isLongEnough)) && text.length > 20) {
        quizData.question = text;
        quizData.found = true;
        quizData.debug.push(`Found question via selector: ${selector}`);
        console.log('✅ Found question:', text.substring(0, 100));
        break;
      }
    }
    if (quizData.found) break;
  }

  // If still not found, look for ANY paragraph with substantial text
  if (!quizData.found) {
    console.log('Trying fallback: looking for any long paragraph...');
    const allParagraphs = document.querySelectorAll('p, div');
    for (const el of allParagraphs) {
      const text = el.textContent.trim();
      if (text.length > 50 && text.length < 2000 && !text.includes('cookie') && !text.includes('privacy')) {
        quizData.question = text;
        quizData.found = true;
        quizData.debug.push('Found question via fallback (long paragraph)');
        console.log('✅ Found question (fallback):', text.substring(0, 100));
        break;
      }
    }
  }

  // Find answer options (radio buttons, checkboxes, or text options)
  let answerInputs = document.querySelectorAll('input[type="radio"], input[type="checkbox"]');
  console.log(`Found ${answerInputs.length} radio/checkbox inputs`);

  // If no inputs found, the quiz might use clickable divs instead
  if (answerInputs.length === 0) {
    console.log('No radio buttons found, looking for clickable answer divs...');
    // We'll still return found=false if we can't find clickable answers
    // But at least we tried
  }

  answerInputs.forEach((input, index) => {
    // Find associated label or nearby text
    let answerText = '';

    // Try to find label by 'for' attribute
    if (input.id) {
      const label = document.querySelector(`label[for="${input.id}"]`);
      if (label) {
        answerText = label.textContent.trim();
      }
    }

    // Try parent label
    if (!answerText) {
      const parentLabel = input.closest('label');
      if (parentLabel) {
        answerText = parentLabel.textContent.trim();
      }
    }

    // Try next sibling
    if (!answerText && input.nextSibling) {
      answerText = input.nextSibling.textContent?.trim() || '';
    }

    // Try parent div text
    if (!answerText) {
      const parent = input.parentElement;
      if (parent) {
        answerText = parent.textContent.trim();
      }
    }

    // Clean up answer text (remove extra whitespace)
    answerText = answerText.replace(/\s+/g, ' ').trim();

    if (answerText && answerText.length > 0) {
      quizData.answers.push({
        index: index + 1,
        text: answerText,
        element: input,
        type: input.type
      });
      console.log(`✅ Answer ${index + 1}:`, answerText.substring(0, 50));
      quizData.debug.push(`Found answer ${index + 1}: ${answerText.substring(0, 30)}...`);
    }
  });

  console.log(`Total answers found: ${quizData.answers.length}`);

  return quizData;
}

// Listen for messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'detectQuiz') {
    const quizData = detectQuiz();
    sendResponse(quizData);
  } else if (request.action === 'clickAnswer') {
    const answerIndex = request.answerIndex;
    const inputs = document.querySelectorAll('input[type="radio"], input[type="checkbox"]');

    if (inputs[answerIndex - 1]) {
      // Scroll into view
      inputs[answerIndex - 1].scrollIntoView({ behavior: 'smooth', block: 'center' });

      // Wait a bit then click
      setTimeout(() => {
        inputs[answerIndex - 1].click();

        // Highlight the answer briefly
        const parent = inputs[answerIndex - 1].closest('label') || inputs[answerIndex - 1].parentElement;
        if (parent) {
          parent.style.backgroundColor = '#90EE90';
          parent.style.transition = 'background-color 0.3s';
          setTimeout(() => {
            parent.style.backgroundColor = '';
          }, 2000);
        }

        sendResponse({ success: true });
      }, 500);
    } else {
      sendResponse({ success: false, error: 'Answer not found' });
    }

    return true; // Keep channel open for async response
  } else if (request.action === 'clickSubmit') {
    // Find and click the submit button
    console.log('Looking for submit button...');

    let submitButton = null;

    // First try: button[type="submit"] or input[type="submit"]
    const typeSubmitButtons = document.querySelectorAll('button[type="submit"], input[type="submit"]');
    if (typeSubmitButtons.length > 0) {
      submitButton = typeSubmitButtons[0];
      console.log('Found submit button by type="submit"');
    }

    // Second try: all buttons, search by text
    if (!submitButton) {
      const allButtons = document.querySelectorAll('button, input[type="button"], a.button, a.btn');
      for (const btn of allButtons) {
        const text = (btn.textContent || btn.value || '').toLowerCase().trim();
        console.log(`Checking button text: "${text}"`);

        if (text === 'submit' ||
            text === 'next' ||
            text === 'continue' ||
            text === 'check' ||
            text.includes('submit') ||
            text.includes('next')) {
          submitButton = btn;
          console.log(`✅ Found button by text: "${text}"`);
          break;
        }
      }
    }

    // Third try: any button on the page (last resort)
    if (!submitButton) {
      const anyButtons = document.querySelectorAll('button');
      console.log(`Found ${anyButtons.length} total buttons on page`);

      // Log all button texts for debugging
      anyButtons.forEach((btn, i) => {
        console.log(`Button ${i}: "${btn.textContent.trim()}"`);
      });

      if (anyButtons.length > 0) {
        // Use the first visible button as last resort
        for (const btn of anyButtons) {
          if (btn.offsetParent !== null) { // Check if visible
            submitButton = btn;
            console.log(`Using first visible button: "${btn.textContent.trim()}"`);
            break;
          }
        }
      }
    }

    if (submitButton) {
      submitButton.scrollIntoView({ behavior: 'smooth', block: 'center' });
      setTimeout(() => {
        console.log('Clicking submit button');
        submitButton.click();
        sendResponse({ success: true });
      }, 500);
    } else {
      console.log('❌ No submit button found');
      sendResponse({ success: false, error: 'Submit button not found' });
    }

    return true; // Keep channel open for async response
  }
});

// Notify that script is ready
console.log('StudyFlowSuite ready to detect quizzes');
